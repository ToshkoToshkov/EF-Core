﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs.Input
{
    public class CategoryProductInputDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
