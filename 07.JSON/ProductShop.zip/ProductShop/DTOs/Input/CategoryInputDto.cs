﻿using System;

namespace ProductShop.DTOs.Input
{
    public class CategoryInputDto
    {
        public string Name { get; set; }
    }
}
