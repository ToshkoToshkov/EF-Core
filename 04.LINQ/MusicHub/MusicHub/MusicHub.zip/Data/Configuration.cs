﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost;Database=MusicHub;User Id=sa;Password=yourStrong(!)Password";
    }
}
