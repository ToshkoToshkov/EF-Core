﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=localhost;Database=VaporStore;User Id=sa;Password=yourStrong(!)Password;";
			//@"Server=.;Database=VaporStrore;Trusted_Connection=True";
			
	}
}