﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            //@"Server=.;Database=SoftJail;Trusted_Connection=True";
            @"Server=localhost;Database=SoftJail;User Id=sa;Password=yourStrong(!)Password;";
    
    }
}
