﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=localhost;Database=FootballBeting;User Id=sa;
            Password=yourStrong(!)Password";
    }
}
