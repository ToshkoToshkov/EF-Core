﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace P01_StudentSystem.Data.Models
{
    public class Resource
    {
        [Key]
        public int ResourceId { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

        //TODO: make non unicode with Fluent-Api
        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        // {
        //   base.OnModelCreating(modelBuilder);
        //   modelBuilder.Properties<string>().Configure(p => p.IsUnicode(false));
        // }
        public string Url { get; set; }

        public Enums.Enumerations ResourceType  { get; set; }

        [ForeignKey(nameof(Course))]
        public int CourseId { get; set; }
        public virtual Course Course { get; set; }
    }
}
