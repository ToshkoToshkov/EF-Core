﻿using System;
using P01_StudentSystem.Data;

namespace P01_StudentSystem
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            StudentSystemContext dbContext = new StudentSystemContext();

            dbContext.Database.EnsureCreated();

            Console.WriteLine("Db created succefully");

            dbContext.Database.EnsureDeleted();
        }
    }
}
